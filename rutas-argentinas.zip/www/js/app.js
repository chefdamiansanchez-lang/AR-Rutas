(function () {
  'use strict';

  /* ---------- utilidades ---------- */
  var $ = function (id) { return document.getElementById(id); };
  var norm = function (s) {
    return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  };
  var store = {
    get: function (k, d) {
      try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; }
    },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };
  var toastTimer = null;
  function toast(msg, ms) {
    var t = $('toast');
    t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.hidden = true; }, ms || 2600);
  }
  function rad(x) { return x * Math.PI / 180; }
  function haversine(lat1, lon1, lat2, lon2) {
    var R = 6371, dLat = rad(lat2 - lat1), dLon = rad(lon2 - lon1);
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 2 * R * Math.asin(Math.sqrt(a));
  }
  function fmt(n, dec) {
    return Number(n).toLocaleString('es-AR', { minimumFractionDigits: dec || 0, maximumFractionDigits: dec || 0 });
  }
  function fmtTiempo(min) {
    var h = Math.floor(min / 60), m = Math.round(min % 60);
    if (m === 60) { h += 1; m = 0; }
    return h > 0 ? h + ' h ' + (m < 10 ? '0' : '') + m + ' min' : m + ' min';
  }

  /* ---------- splash DATCO ---------- */
  window.addEventListener('load', function () {
    setTimeout(function () {
      var s = $('splash');
      if (!s) return;
      s.classList.add('hide');
      setTimeout(function () { if (s.parentNode) s.parentNode.removeChild(s); }, 700);
    }, 2800);
  });

  /* ---------- datos ---------- */
  var CITY = {};
  CIUDADES.forEach(function (c) { CITY[c[0]] = { nombre: c[0], prov: c[1], lat: c[2], lon: c[3] }; });
  var CITY_LIST = Object.keys(CITY).map(function (k) { return CITY[k]; });
  function cityLabel(c) { return c.nombre + ', ' + c.prov; }

  var dl = $('dlCiudades');
  CITY_LIST.slice().sort(function (a, b) { return a.nombre.localeCompare(b.nombre, 'es'); }).forEach(function (c) {
    var o = document.createElement('option'); o.value = cityLabel(c); dl.appendChild(o);
  });

  function findCity(text) {
    var n = norm(text);
    if (!n) return null;
    var i, c;
    for (i = 0; i < CITY_LIST.length; i++) { c = CITY_LIST[i]; if (norm(cityLabel(c)) === n) return c; }
    for (i = 0; i < CITY_LIST.length; i++) { c = CITY_LIST[i]; if (norm(c.nombre) === n) return c; }
    for (i = 0; i < CITY_LIST.length; i++) { c = CITY_LIST[i]; if (norm(c.nombre).indexOf(n) === 0) return c; }
    return null;
  }

  /* ---------- mapa ---------- */
  var map = L.map('map', { zoomControl: false, minZoom: 3 }).setView([-38.4, -63.6], 4);
  L.control.zoom({ position: 'topright' }).addTo(map);
  var TILE_URL = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  L.tileLayer(TILE_URL, { maxZoom: 17, attribution: '© OpenStreetMap' }).addTo(map);

  var gNac = L.layerGroup().addTo(map);
  var gProv = L.layerGroup().addTo(map);
  var gCiu = L.layerGroup();
  var routeLayers = {};

  RUTAS.forEach(function (r) {
    var pts = [];
    r.pasa.forEach(function (n) {
      if (CITY[n]) pts.push([CITY[n].lat, CITY[n].lon]);
    });
    if (pts.length < 2) return;
    var color = r.tipo === 'nacional' ? '#0b6bcb' : '#f08a00';
    var grp = r.tipo === 'nacional' ? gNac : gProv;
    var line = L.polyline(pts, { color: color, weight: 4, opacity: 0.9 }).addTo(grp);
    line.bindPopup('<b>' + r.ref + '</b><br><small>' + r.desc + '</small>');
    var mid = pts[Math.floor(pts.length / 2)];
    var icon = L.divIcon({
      className: 'shield-wrap',
      html: '<span class="shield ' + (r.tipo === 'nacional' ? 'nac' : 'prov') + '">' + r.ref.replace(/ \(.*\)/, '') + '</span>',
      iconSize: [46, 18], iconAnchor: [23, 9]
    });
    L.marker(mid, { icon: icon, interactive: false, keyboard: false }).addTo(grp);
    routeLayers[r.ref] = { line: line, tipo: r.tipo };
  });

  function cityPopup(c) {
    var d = document.createElement('div'); d.className = 'pp';
    var b = document.createElement('b'); b.textContent = c.nombre;
    var s = document.createElement('small'); s.textContent = c.prov;
    var btns = document.createElement('div'); btns.className = 'pp-btns';
    var bo = document.createElement('button'); bo.textContent = 'Origen';
    var bd = document.createElement('button'); bd.textContent = 'Destino';
    bo.onclick = function () { $('origen').value = cityLabel(c); map.closePopup(); toast('Origen: ' + c.nombre); };
    bd.onclick = function () { $('destino').value = cityLabel(c); map.closePopup(); toast('Destino: ' + c.nombre); };
    btns.appendChild(bo); btns.appendChild(bd);
    d.appendChild(b); d.appendChild(document.createElement('br')); d.appendChild(s); d.appendChild(btns);
    return d;
  }
  CITY_LIST.forEach(function (c) {
    L.circleMarker([c.lat, c.lon], { radius: 5, color: '#fff', weight: 1.5, fillColor: '#475569', fillOpacity: 1 })
      .bindPopup(function () { return cityPopup(c); })
      .bindTooltip(c.nombre, { direction: 'top', offset: [0, -4] })
      .addTo(gCiu);
  });

  var chipState = { nac: true, prov: true, ciu: true };
  function aplicarCiudades() {
    var quiero = chipState.ciu && map.getZoom() >= 6;
    if (quiero && !map.hasLayer(gCiu)) map.addLayer(gCiu);
    if (!quiero && map.hasLayer(gCiu)) map.removeLayer(gCiu);
  }
  function bindChip(id, key, group) {
    $(id).addEventListener('click', function () {
      chipState[key] = !chipState[key];
      this.classList.toggle('on', chipState[key]);
      if (group) { if (chipState[key]) map.addLayer(group); else map.removeLayer(group); }
      else aplicarCiudades();
    });
  }
  bindChip('chipNac', 'nac', gNac);
  bindChip('chipProv', 'prov', gProv);
  bindChip('chipCiu', 'ciu', null);
  map.on('zoomend', aplicarCiudades);
  aplicarCiudades();

  /* ---------- pestañas ---------- */
  function showTab(name) {
    ['mapa', 'recorrido', 'rutas', 'alertas'].forEach(function (t) {
      $('tab-' + t).classList.toggle('active', t === name);
    });
    var bs = document.querySelectorAll('.tb');
    for (var i = 0; i < bs.length; i++) bs[i].classList.toggle('on', bs[i].getAttribute('data-tab') === name);
    if (name === 'mapa') setTimeout(function () { map.invalidateSize(); }, 50);
  }
  var tbs = document.querySelectorAll('.tb');
  for (var ti = 0; ti < tbs.length; ti++) {
    tbs[ti].addEventListener('click', function () { showTab(this.getAttribute('data-tab')); });
  }

  /* ---------- ubicación ---------- */
  var lastPos = null, watchId = null, meMarker = null, meCircle = null;

  function onPos(p, centrar) {
    lastPos = { lat: p.coords.latitude, lon: p.coords.longitude, acc: p.coords.accuracy };
    var ll = [lastPos.lat, lastPos.lon];
    if (!meMarker) {
      meMarker = L.marker(ll, {
        icon: L.divIcon({ className: '', html: '<div class="me-dot"></div>', iconSize: [16, 16], iconAnchor: [8, 8] }),
        interactive: false, zIndexOffset: 1000
      }).addTo(map);
      meCircle = L.circle(ll, { radius: lastPos.acc, color: '#1a73e8', weight: 1, fillOpacity: 0.1 }).addTo(map);
    } else {
      meMarker.setLatLng(ll); meCircle.setLatLng(ll); meCircle.setRadius(lastPos.acc);
    }
    if (centrar) map.setView(ll, Math.max(map.getZoom(), 12));
    actualizarEstadoRuta();
  }
  function detenerUbic() {
    if (watchId !== null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
    watchId = null;
    $('btnUbic').classList.remove('on');
  }
  function toggleUbic() {
    if (watchId !== null) {
      detenerUbic();
      if (meMarker) { map.removeLayer(meMarker); map.removeLayer(meCircle); meMarker = null; meCircle = null; }
      lastPos = null; $('estadoRuta').hidden = true;
      toast('Ubicación desactivada');
      return;
    }
    if (!navigator.geolocation) { toast('Este dispositivo no permite obtener la ubicación'); return; }
    toast('Buscando tu ubicación…');
    var primera = true;
    watchId = navigator.geolocation.watchPosition(function (p) {
      onPos(p, primera); primera = false;
    }, function () {
      toast('No pude obtener tu ubicación. Revisá el permiso y el GPS.', 3500);
      detenerUbic();
    }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 25000 });
    $('btnUbic').classList.add('on');
  }
  $('btnUbic').addEventListener('click', toggleUbic);

  function ubicacionUnaVez() {
    return new Promise(function (resolve) {
      if (lastPos) return resolve({ nombre: 'Mi ubicación', prov: '', lat: lastPos.lat, lon: lastPos.lon });
      if (!navigator.geolocation) return resolve(null);
      navigator.geolocation.getCurrentPosition(function (p) {
        resolve({ nombre: 'Mi ubicación', prov: '', lat: p.coords.latitude, lon: p.coords.longitude });
      }, function () { resolve(null); }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 10000 });
    });
  }
  $('btnMiUbic').addEventListener('click', function () { $('origen').value = 'Mi ubicación'; toast('Origen: tu ubicación'); });
  $('btnSwap').addEventListener('click', function () {
    var o = $('origen').value; $('origen').value = $('destino').value; $('destino').value = o;
  });

  /* ---------- combustible ---------- */
  var VEH = {
    nafta:     { unidad: 'L',   nombre: 'nafta',  lblCons: 'Consumo (litros cada 100 km)', lblPrecio: 'Precio de la nafta por litro ($)', defCons: 8 },
    gasoil:    { unidad: 'L',   nombre: 'gasoil', lblCons: 'Consumo (litros cada 100 km)', lblPrecio: 'Precio del gasoil por litro ($)', defCons: 6.5 },
    electrico: { unidad: 'kWh', nombre: 'electricidad', lblCons: 'Consumo (kWh cada 100 km)', lblPrecio: 'Precio por kWh ($)', defCons: 16 }
  };
  var veh = store.get('veh', null) || { tipo: 'nafta', cons: {}, precio: {}, idaVuelta: false };
  if (!veh.cons) veh.cons = {}; if (!veh.precio) veh.precio = {};

  function cargarVeh() {
    var v = VEH[veh.tipo];
    var bs = document.querySelectorAll('#segVeh button');
    for (var i = 0; i < bs.length; i++) bs[i].classList.toggle('on', bs[i].getAttribute('data-v') === veh.tipo);
    $('lblCons').textContent = v.lblCons;
    $('lblPrecio').textContent = v.lblPrecio;
    $('cons').value = veh.cons[veh.tipo] !== undefined ? veh.cons[veh.tipo] : v.defCons;
    $('precio').value = veh.precio[veh.tipo] !== undefined ? veh.precio[veh.tipo] : '';
    $('idaVuelta').checked = !!veh.idaVuelta;
  }
  function guardarVeh() {
    veh.cons[veh.tipo] = $('cons').value;
    veh.precio[veh.tipo] = $('precio').value;
    veh.idaVuelta = $('idaVuelta').checked;
    store.set('veh', veh);
  }
  var segBtns = document.querySelectorAll('#segVeh button');
  for (var si = 0; si < segBtns.length; si++) {
    segBtns[si].addEventListener('click', function () {
      guardarVeh();
      veh.tipo = this.getAttribute('data-v');
      cargarVeh(); renderResultado();
    });
  }
  ['cons', 'precio', 'idaVuelta'].forEach(function (id) {
    $(id).addEventListener('input', function () { guardarVeh(); renderResultado(); });
    $(id).addEventListener('change', function () { guardarVeh(); renderResultado(); });
  });
  cargarVeh();

  /* ---------- rutas: cálculo ---------- */
  var lastResult = null;   // { a, b, km, min, coords, estimada, delCache }
  var routeGroup = L.layerGroup().addTo(map);
  var currentRoute = null; // { coords, cum }

  function withTimeout(promise, ms) {
    return Promise.race([promise, new Promise(function (_, rej) { setTimeout(function () { rej(new Error('timeout')); }, ms); })]);
  }
  function keyRuta(a, b) {
    return a.lat.toFixed(2) + ',' + a.lon.toFixed(2) + '>' + b.lat.toFixed(2) + ',' + b.lon.toFixed(2);
  }
  function simplificar(coords, max) {
    if (coords.length <= max) return coords;
    var paso = Math.ceil(coords.length / max), out = [];
    for (var i = 0; i < coords.length; i += paso) out.push(coords[i]);
    out.push(coords[coords.length - 1]);
    return out;
  }
  function rutaDesdeCache(a, b) {
    var c = store.get('rutasCache', {});
    var e = c[keyRuta(a, b)];
    if (e) return { km: e.km, min: e.min, coords: e.coords, estimada: false, delCache: true };
    return null;
  }
  function guardarCache(a, b, r) {
    var c = store.get('rutasCache', {}), ord = store.get('rutasCacheOrden', []), k = keyRuta(a, b);
    c[k] = { km: r.km, min: r.min, coords: simplificar(r.coords, 500) };
    ord = ord.filter(function (x) { return x !== k; }); ord.push(k);
    while (ord.length > 12) { delete c[ord.shift()]; }
    store.set('rutasCache', c); store.set('rutasCacheOrden', ord);
  }
  function obtenerRuta(a, b) {
    var url = 'https://router.project-osrm.org/route/v1/driving/' +
      a.lon + ',' + a.lat + ';' + b.lon + ',' + b.lat + '?overview=full&geometries=geojson';
    return withTimeout(fetch(url).then(function (r) { return r.json(); }), 20000).then(function (d) {
      if (!d || !d.routes || !d.routes.length) throw new Error('sin ruta');
      var rt = d.routes[0];
      var coords = rt.geometry.coordinates.map(function (p) { return [p[1], p[0]]; });
      var res = { km: rt.distance / 1000, min: rt.duration / 60, coords: coords, estimada: false, delCache: false };
      guardarCache(a, b, res);
      return res;
    }).catch(function () {
      var c = rutaDesdeCache(a, b);
      if (c) return c;
      var km = haversine(a.lat, a.lon, b.lat, b.lon) * 1.25;
      return { km: km, min: km / 80 * 60, coords: [[a.lat, a.lon], [b.lat, b.lon]], estimada: true, delCache: false };
    });
  }

  function resolverPunto(texto, rol) {
    var n = norm(texto);
    if (!n) { toast('Elegí ' + rol.toLowerCase()); return Promise.resolve(null); }
    if (n === 'mi ubicacion') {
      toast('Obteniendo tu ubicación…');
      return ubicacionUnaVez().then(function (p) {
        if (!p) toast('No pude obtener tu ubicación');
        return p;
      });
    }
    var c = findCity(texto);
    if (!c) toast('No encontré “' + texto + '” en la lista de ciudades', 3500);
    return Promise.resolve(c);
  }

  function calcular() {
    var btn = $('btnCalc');
    var a, b;
    resolverPunto($('origen').value, 'Origen').then(function (pa) {
      if (!pa) return null; a = pa;
      return resolverPunto($('destino').value, 'Destino');
    }).then(function (pb) {
      if (!pb || !a) return null; b = pb;
      if (haversine(a.lat, a.lon, b.lat, b.lon) < 0.5) { toast('El origen y el destino son el mismo lugar'); return null; }
      btn.disabled = true; btn.textContent = 'Calculando…';
      return obtenerRuta(a, b);
    }).then(function (r) {
      btn.disabled = false; btn.textContent = 'Calcular recorrido';
      if (!r) return;
      r.a = a; r.b = b;
      lastResult = r;
      renderResultado();
      dibujarRuta(r);
      buscarAlertasRuta(r);
    }).catch(function () {
      btn.disabled = false; btn.textContent = 'Calcular recorrido';
      toast('Ocurrió un error al calcular el recorrido');
    });
  }
  $('btnCalc').addEventListener('click', calcular);

  function renderResultado() {
    var box = $('resultado');
    if (!lastResult) { box.hidden = true; return; }
    var r = lastResult, v = VEH[veh.tipo];
    var factor = $('idaVuelta').checked ? 2 : 1;
    var km = r.km * factor, min = r.min * factor;
    var cons = parseFloat(String($('cons').value).replace(',', '.'));
    var precio = parseFloat(String($('precio').value).replace(',', '.'));
    $('rTitulo').textContent = r.a.nombre + ' → ' + r.b.nombre + (factor === 2 ? ' (ida y vuelta)' : '');
    $('rKm').textContent = fmt(km, 0) + ' km';
    $('rTiempo').textContent = fmtTiempo(min);
    $('rLblCons').textContent = 'Consumo de ' + v.nombre;
    if (isFinite(cons) && cons > 0) {
      var cant = km * cons / 100;
      $('rCons').textContent = fmt(cant, 1) + ' ' + v.unidad;
      $('rCosto').textContent = (isFinite(precio) && precio > 0) ? '$ ' + fmt(cant * precio, 0) : 'Cargá el precio';
    } else {
      $('rCons').textContent = '—'; $('rCosto').textContent = '—';
    }
    var av = $('rAviso');
    if (r.estimada) {
      av.hidden = false;
      av.textContent = '⚠ Sin conexión: distancia estimada en línea recta × 1,25 y 80 km/h de promedio. Con internet se calcula por la ruta real.';
    } else if (r.delCache) {
      av.hidden = false;
      av.textContent = 'Recorrido guardado de una consulta anterior (sin conexión).';
    } else {
      av.hidden = true;
    }
    box.hidden = false;
  }

  function dibujarRuta(r) {
    routeGroup.clearLayers();
    var line = L.polyline(r.coords, { color: '#e53935', weight: 6, opacity: 0.85, dashArray: r.estimada ? '10 10' : null });
    routeGroup.addLayer(line);
    var pin = function (txt) {
      return L.divIcon({ className: '', html: '<div class="pin">' + txt + '</div>', iconSize: [24, 24], iconAnchor: [12, 22] });
    };
    routeGroup.addLayer(L.marker([r.a.lat, r.a.lon], { icon: pin('🟢') }).bindTooltip(r.a.nombre));
    routeGroup.addLayer(L.marker([r.b.lat, r.b.lon], { icon: pin('🏁') }).bindTooltip(r.b.nombre));
    var cum = [0];
    for (var i = 1; i < r.coords.length; i++) {
      cum.push(cum[i - 1] + haversine(r.coords[i - 1][0], r.coords[i - 1][1], r.coords[i][0], r.coords[i][1]));
    }
    currentRoute = { coords: r.coords, cum: cum, total: cum[cum.length - 1] };
    map.fitBounds(line.getBounds(), { padding: [40, 40] });
    actualizarEstadoRuta();
  }
  $('btnVerMapa').addEventListener('click', function () {
    showTab('mapa');
    if (lastResult) setTimeout(function () { dibujarRuta(lastResult); }, 120);
  });

  function actualizarEstadoRuta() {
    var el = $('estadoRuta');
    if (!currentRoute || !lastPos) { el.hidden = true; return; }
    var best = Infinity, idx = 0, cs = currentRoute.coords;
    for (var i = 0; i < cs.length; i++) {
      var d = haversine(lastPos.lat, lastPos.lon, cs[i][0], cs[i][1]);
      if (d < best) { best = d; idx = i; }
    }
    var falta = Math.max(0, currentRoute.total - currentRoute.cum[idx]);
    el.hidden = false;
    if (best < 1.5) el.textContent = '✅ Estás sobre la ruta · faltan ' + fmt(falta, 0) + ' km';
    else el.textContent = 'Estás a ' + fmt(best, best < 10 ? 1 : 0) + ' km de la ruta';
  }

  /* ---------- alertas SMN (mejor esfuerzo) ---------- */
  var SMN_URL = 'https://ssl.smn.gob.ar/CAP/AR.php';
  var alertas = { ok: false, items: [], cargado: false };

  function textoDe(node, tags) {
    for (var i = 0; i < tags.length; i++) {
      var el = node.getElementsByTagName(tags[i])[0];
      if (el && el.textContent && el.textContent.trim()) return el.textContent.trim();
    }
    return '';
  }
  function parsearCap(txt) {
    var doc = new DOMParser().parseFromString(txt, 'text/xml');
    if (doc.getElementsByTagName('parsererror').length) return null;
    var nodes = doc.getElementsByTagName('entry');
    if (!nodes.length) nodes = doc.getElementsByTagName('item');
    if (!nodes.length) nodes = doc.getElementsByTagName('alert');
    var out = [];
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      var titulo = textoDe(n, ['headline', 'title', 'event']);
      var detalle = textoDe(n, ['description', 'summary', 'content']);
      var zonas = [];
      var ad = n.getElementsByTagName('areaDesc');
      for (var j = 0; j < ad.length; j++) zonas.push(ad[j].textContent.trim());
      var sev = textoDe(n, ['severity']);
      if (!titulo && !detalle) continue;
      out.push({ titulo: titulo || 'Alerta', detalle: detalle, zona: zonas.join(', '), sev: sev, texto: (titulo + ' ' + detalle + ' ' + zonas.join(' ')) });
    }
    return out;
  }
  function cargarAlertas() {
    return withTimeout(fetch(SMN_URL).then(function (r) { return r.text(); }), 20000).then(function (txt) {
      var it = parsearCap(txt);
      if (it === null) throw new Error('formato');
      alertas = { ok: true, items: it, cargado: true };
      return alertas;
    }).catch(function () {
      alertas = { ok: false, items: [], cargado: true };
      return alertas;
    });
  }
  function htmlAlerta(a) {
    var d = document.createElement('div'); d.className = 'al';
    var b = document.createElement('b'); b.textContent = a.titulo; d.appendChild(b);
    var info = [a.sev, a.zona].filter(Boolean).join(' · ');
    if (info) { var s = document.createElement('small'); s.textContent = info; d.appendChild(s); }
    if (a.detalle) { var p = document.createElement('small'); p.textContent = a.detalle.slice(0, 220); d.appendChild(p); }
    return d;
  }
  function renderListaAlertas() {
    var box = $('listaAlertas'); box.textContent = '';
    if (!alertas.ok) { box.textContent = 'Dato no disponible: no pude leer las alertas del SMN ahora (sin conexión o cambio en su servicio). Podés verlas en el sitio del SMN.'; return; }
    if (!alertas.items.length) { box.textContent = 'El SMN no informa alertas vigentes en este momento.'; return; }
    alertas.items.forEach(function (a) { box.appendChild(htmlAlerta(a)); });
  }
  $('btnAlertas').addEventListener('click', function () {
    $('listaAlertas').textContent = 'Consultando…';
    cargarAlertas().then(renderListaAlertas);
  });

  function provinciasDeRuta(r) {
    var set = {}; set[r.a.prov] = 1; set[r.b.prov] = 1;
    var pts = simplificar(r.coords, 300);
    CITY_LIST.forEach(function (c) {
      for (var i = 0; i < pts.length; i++) {
        if (haversine(c.lat, c.lon, pts[i][0], pts[i][1]) < 40) { set[c.prov] = 1; break; }
      }
    });
    delete set['']; return Object.keys(set);
  }
  function buscarAlertasRuta(r) {
    var box = $('rAlertas'); box.textContent = 'Consultando alertas del SMN…';
    var provs = provinciasDeRuta(r);
    var p = alertas.cargado && alertas.ok ? Promise.resolve(alertas) : cargarAlertas();
    p.then(function (al) {
      box.textContent = '';
      var h = document.createElement('b'); h.textContent = 'Alertas del SMN en tu recorrido';
      box.appendChild(h);
      if (!al.ok) {
        var m = document.createElement('div'); m.className = 'al';
        m.textContent = 'Dato no disponible ahora. Revisá la pestaña Alertas o el sitio del SMN antes de salir.';
        box.appendChild(m); return;
      }
      var hit = al.items.filter(function (a) {
        var t = norm(a.texto);
        return provs.some(function (pv) {
          var np = norm(pv);
          if (np === 'caba') return t.indexOf('ciudad de buenos aires') >= 0 || t.indexOf('caba') >= 0;
          return t.indexOf(np) >= 0;
        });
      });
      if (!hit.length) {
        var n = document.createElement('div'); n.className = 'al';
        n.textContent = 'Sin alertas vigentes para las provincias del recorrido (' + provs.join(', ') + ').';
        box.appendChild(n);
      } else hit.forEach(function (a) { box.appendChild(htmlAlerta(a)); });
      var ruta = document.createElement('small');
      ruta.style.cssText = 'display:block;margin-top:8px;color:#8b97a8';
      ruta.textContent = 'Estado de rutas y cortes: llamá a Vialidad Nacional (0800-222-6272) antes de salir.';
      box.appendChild(ruta);
    });
  }

  /* ---------- lista de rutas ---------- */
  function renderRutas(filtro) {
    var cont = $('listaRutas'); cont.textContent = '';
    var f = norm(filtro);
    RUTAS.forEach(function (r) {
      if (f && norm(r.ref + ' ' + r.desc).indexOf(f) < 0) return;
      var it = document.createElement('div'); it.className = 'ri';
      var sh = document.createElement('span'); sh.className = 'shield ' + (r.tipo === 'nacional' ? 'nac' : 'prov'); sh.textContent = r.ref;
      var ds = document.createElement('span'); ds.className = 'd'; ds.textContent = r.desc;
      it.appendChild(sh); it.appendChild(ds);
      it.addEventListener('click', function () {
        var rl = routeLayers[r.ref]; if (!rl) return;
        var key = r.tipo === 'nacional' ? 'nac' : 'prov';
        if (!chipState[key]) { $(key === 'nac' ? 'chipNac' : 'chipProv').click(); }
        showTab('mapa');
        setTimeout(function () { map.fitBounds(rl.line.getBounds(), { padding: [40, 40] }); rl.line.openPopup(); }, 150);
      });
      cont.appendChild(it);
    });
    if (!cont.childNodes.length) cont.textContent = 'No hay rutas que coincidan.';
  }
  $('buscaRuta').addEventListener('input', function () { renderRutas(this.value); });
  renderRutas('');

  /* ---------- mapa sin conexión ---------- */
  function lng2tile(lon, z) { return Math.floor((lon + 180) / 360 * Math.pow(2, z)); }
  function lat2tile(lat, z) {
    var r = rad(lat);
    return Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * Math.pow(2, z));
  }
  function tilesDe(bounds, z) {
    var x0 = lng2tile(bounds.getWest(), z), x1 = lng2tile(bounds.getEast(), z);
    var y0 = lat2tile(bounds.getNorth(), z), y1 = lat2tile(bounds.getSouth(), z);
    var out = [], max = Math.pow(2, z) - 1;
    for (var x = Math.max(0, x0); x <= Math.min(max, x1); x++) {
      for (var y = Math.max(0, y0); y <= Math.min(max, y1); y++) out.push([z, x, y]);
    }
    return out;
  }
  var descargando = false;
  function descargarZona() {
    if (descargando) return;
    var b = map.getBounds(), z = Math.round(map.getZoom()), lista = [];
    for (var zz = z; zz <= Math.min(z + 2, 16); zz++) {
      var t = tilesDe(b, zz);
      if (lista.length + t.length > 300) break;
      lista = lista.concat(t);
    }
    if (!lista.length) { toast('La zona es muy grande. Acercá el mapa y probá de nuevo.', 3500); return; }
    if (!('serviceWorker' in navigator) || !navigator.serviceWorker.controller) {
      toast('El guardado sin conexión se activa en unos segundos. Probá de nuevo.', 3500); return;
    }
    if (!confirm('Se guardarán ' + lista.length + ' mosaicos del mapa de la zona visible para usarlos sin conexión. ¿Continuar?')) return;
    descargando = true;
    var hechos = 0, idx = 0, activos = 0;
    function siguiente() {
      while (activos < 4 && idx < lista.length) {
        var t = lista[idx++]; activos++;
        var img = new Image();
        var fin = function () {
          activos--; hechos++;
          if (hechos % 25 === 0 || hechos === lista.length) toast('Guardando mapa… ' + hechos + '/' + lista.length, 1500);
          if (hechos >= lista.length) { descargando = false; toast('Zona guardada para uso sin conexión ✅', 3000); }
          else siguiente();
        };
        img.onload = fin; img.onerror = fin;
        img.src = TILE_URL.replace('{z}', t[0]).replace('{x}', t[1]).replace('{y}', t[2]);
      }
    }
    siguiente();
  }
  $('btnOffline').addEventListener('click', descargarZona);

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(function () {});
  }
})();
