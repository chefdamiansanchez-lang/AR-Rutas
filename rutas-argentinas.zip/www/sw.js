/* Guarda en el dispositivo los mosaicos del mapa que ya viste, para usarlos sin conexión */
var TILES = 'tiles-v1';
var MAX_TILES = 2500;

self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });

function recortar(cache) {
  return cache.keys().then(function (keys) {
    if (keys.length <= MAX_TILES) return;
    var borrar = keys.slice(0, keys.length - MAX_TILES);
    return Promise.all(borrar.map(function (k) { return cache.delete(k); }));
  });
}

self.addEventListener('fetch', function (e) {
  var url = e.request.url;
  if (e.request.method !== 'GET' || url.indexOf('https://tile.openstreetmap.org/') !== 0) return;
  e.respondWith(
    caches.open(TILES).then(function (cache) {
      return cache.match(url).then(function (hit) {
        if (hit) return hit;
        return fetch(new Request(url, { mode: 'cors', credentials: 'omit' })).then(function (resp) {
          if (resp && resp.ok) { cache.put(url, resp.clone()).then(function () { return recortar(cache); }); }
          return resp;
        });
      });
    })
  );
});
