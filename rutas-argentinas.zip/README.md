# Rutas Argentinas — DATCO

App instalable (Android) con mapa de rutas argentinas, recorridos entre ciudades y cálculo de consumo (nafta, gasoil o electricidad).

## Cómo compilar
1. Subí el contenido de este proyecto a un repositorio de GitHub.
2. Subí `build-apk.yml` en la carpeta `.github/workflows/`.
3. En la pestaña **Actions** se compila solo (o tocá *Run workflow*).
4. Al terminar, descargá `app-debug.apk` desde **Releases** del repositorio e instalalo en el móvil.
